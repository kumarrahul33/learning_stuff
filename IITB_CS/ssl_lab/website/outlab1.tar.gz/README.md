
210050128
Rahul Kumar
<link>

# References 
- https://fontawesome.com/
- https://getbootstrap.com/
- https://developer.mozilla.org/en-US/
- https://sweetalert.js.org/

# Bootstrap
Bootstrap has been extensively used for styling and positioning. It also used to make the website mobile friendly and responsive.

# Sweet Alert
for making good looking alert i have used sweet altert.

