g++ planner.cpp 
./a.out